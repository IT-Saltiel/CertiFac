﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Http;
using System.IO;
using System.Text;

namespace WS
{
    public partial class WebServiceCertiFac : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           

        }

        private void ValidarDocumento()
        {
            try
            {
                string lsResultado = "";
                string cadena = "";
                ServiceReference1.WsFactClient wsFactClient = new ServiceReference1.WsFactClient();
                ServiceReference1.MessageRequest messageRequest = new ServiceReference1.MessageRequest();
                ServiceReference1.MessageResponse messageResponse = new ServiceReference1.MessageResponse();
                ServiceReference1.Operacion operacion = new ServiceReference1.Operacion();

                System.Net.WebClient w;
                if (FileUpload1.HasFile)
                {
                    string extension = System.IO.Path.GetExtension(FileUpload1.FileName).ToUpper();
                    if (extension.Equals(".XML"))
                    {
                        wsFactClient.Open();

                        if (wsFactClient.State == CommunicationState.Opened)
                        {
                            messageRequest.xmlBase64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(FileUpload1.FileBytes.ToString()));                            
                            messageRequest.operacion = ServiceReference1.Operacion.Emision;
                            messageRequest.tipoEmisor = ServiceReference1.TipoEmisor.Direct;
                            messageRequest.apiKey = "";                            
                            messageRequest.rfcEmisor = "EKU9003173C9";
                            messageResponse = wsFactClient.ProcessDocument(messageRequest);
                            Response.Clear();
                            Response.Buffer = true;
                            Response.ContentType = "application/vnd.ms-excel";
                            Response.AddHeader("Content-Disposition", "attachment;filename=WsRespuesta.pdf");
                            Response.Charset = "UTF-8";
                            Response.ContentEncoding = System.Text.Encoding.Default;
                            Response.Write(messageResponse.XmlBase64);
                            Response.End();                          
                            //HttpContext.Current.Response.BinaryWrite(System.IO.File.ReadAllBytes(Encoding.UTF8.GetString(Convert.FromBase64String(messageResponse.XmlBase64))));
                          

                        }
                        if (wsFactClient.State == CommunicationState.Closed)
                        {
                            lsResultado = "C - Comunicacion cerrada, error";
                        }
                        if (wsFactClient.State == CommunicationState.Faulted)
                        {
                            lsResultado = "C - Comunicacion fallida, error. Reintente";
                        }
                        if (wsFactClient.State == CommunicationState.Closed)
                        {
                            lsResultado = "C - Comunicacion cerrada, error. Reintente";
                        }
                        


                    }

                }

                    
              
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        protected void bttnObtenerPDF_Click(object sender, EventArgs e)
        {
            ValidarDocumento();
        }
    }
}