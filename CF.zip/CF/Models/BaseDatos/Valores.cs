﻿using System;
using System.Collections.Generic;

namespace CF.Models.BaseDatos
{
    public partial class Valores
    {
        public string AztecaValor { get; set; }
    }
}
