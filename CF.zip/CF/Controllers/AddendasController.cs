﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CF.Models.BaseDatos;

namespace CF.Controllers
{
    public class AddendasController : Controller
    {
        private readonly cer_addendasContext _context;

        public AddendasController(cer_addendasContext context)
        {
            _context = context;
        }

        // GET: Addendas
        public async Task<IActionResult> Index()
        {
            return View(await _context.Addendas.ToListAsync());
        }

        // GET: Addendas/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var addendas = await _context.Addendas
                .FirstOrDefaultAsync(m => m.IdAddenda == id);
            if (addendas == null)
            {
                return NotFound();
            }

            return View(addendas);
        }

        // GET: Addendas/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Addendas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdAddenda,NombreAddenda,Xml,FechaModificacion,Usuario,Estado")] Addendas addendas)
        {
            if (ModelState.IsValid)
            {
                addendas.IdAddenda = Guid.NewGuid();
                _context.Add(addendas);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(addendas);
        }

        // GET: Addendas/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var addendas = await _context.Addendas.FindAsync(id);
            if (addendas == null)
            {
                return NotFound();
            }
            return View(addendas);
        }

        // POST: Addendas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("IdAddenda,NombreAddenda,Xml,FechaModificacion,Usuario,Estado")] Addendas addendas)
        {
            if (id != addendas.IdAddenda)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(addendas);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AddendasExists(addendas.IdAddenda))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(addendas);
        }

        // GET: Addendas/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var addendas = await _context.Addendas
                .FirstOrDefaultAsync(m => m.IdAddenda == id);
            if (addendas == null)
            {
                return NotFound();
            }

            return View(addendas);
        }

        // POST: Addendas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var addendas = await _context.Addendas.FindAsync(id);
            _context.Addendas.Remove(addendas);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AddendasExists(Guid id)
        {
            return _context.Addendas.Any(e => e.IdAddenda == id);
        }
    }
}
